import React from 'react';

export function Description({description}){
    return <p>{description}</p>;
  }