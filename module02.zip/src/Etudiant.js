
export function Etudiant({etudiant}){
    return(
        <tr>
        <td>{etudiant.nom}</td>
        <td>{etudiant.matricule}</td>
        </tr>
    )
}