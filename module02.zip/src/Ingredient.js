
export function Ingredient({ingredient}){
    return (
      <div>
        <li>{ingredient}</li>
      </div>
    )
  }