
export function Instruction({instructions}){
    return (
      <div>
        <li>{instructions}</li>
      </div>
    )
  }