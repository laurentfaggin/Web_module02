
export function TitrePrincipal({titre}){
    return <h1>{titre}</h1>;
  }