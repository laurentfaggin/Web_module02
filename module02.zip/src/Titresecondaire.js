
export function TitreSecondaire({titre}){
    return <h2>{titre}</h2>
}