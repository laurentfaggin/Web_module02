import React from 'react';

export function Instruction({instructions}){
    return (
      <div>
        <li>{instructions}</li>
      </div>
    )
  }